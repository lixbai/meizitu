module.exports = require('./compile/runtime');
